DEBUG=True
SECRET_KEY = 'development key'

#SQLALCHEMY_DATABASE_URI = 'mysql+pymysql://root:yutian@192.168.78.128/cmdb_v2'
#SQLALCHEMY_TRACK_MODIFICATIONS = True
SQL_HOST = '104.199.207.83'
SQL_USER = 'qinl'
SQL_PASSWD = 'qinl@#^##112'
SQL_DB = 'cmdb'

FIELDS=['id','username','username_cn','password','sex','age','phone','email','role','create_time','last_time']