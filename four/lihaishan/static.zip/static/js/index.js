console.log("欢迎大家关注我的微博：说Z先生爱你");
console.log("欢迎大家关注我的个人网站：zrong.me");